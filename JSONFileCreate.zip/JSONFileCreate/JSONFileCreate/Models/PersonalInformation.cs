﻿namespace JSONFileCreate.Models
{
    public class PersonalInformation
    {
        public string FName { get; set; }
        public string LName { get; set; }
    }
}
